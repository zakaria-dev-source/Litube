package com.hhst.youtubelite.extension;

import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ExtensionManager {

	private final SharedPreferences prefs;

	@Inject
	public ExtensionManager(SharedPreferences prefs) {
		this.prefs = prefs;
		initializeDefaultPreferences();
	}

	private void initializeDefaultPreferences() {
		SharedPreferences.Editor editor = prefs.edit();
		boolean changed = false;
		for (Map.Entry<String, Boolean> entry : Constant.DEFAULT_PREFERENCES.entrySet()) {
			String key = "preferences:" + entry.getKey();
			if (!prefs.contains(key)) {
				editor.putBoolean(key, entry.getValue());
				changed = true;
			}
		}
		if (changed) editor.apply();
	}

	public void setEnabled(String key, boolean enable) {
		prefs.edit().putBoolean("preferences:" + key, enable).apply();
	}

	public boolean isEnabled(String key) {
		return prefs.getBoolean("preferences:" + key,
				Boolean.TRUE.equals(Constant.DEFAULT_PREFERENCES.getOrDefault(key, false)));
	}

	public Map<String, Boolean> getAllPreferences() {
		Map<String, Boolean> allPreferences = new HashMap<>();
		for (String key : Constant.DEFAULT_PREFERENCES.keySet()) {
			allPreferences.put(key, isEnabled(key));
		}
		return allPreferences;
	}

}
